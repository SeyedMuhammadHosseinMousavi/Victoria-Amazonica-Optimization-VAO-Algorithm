latSeattle = 45;
lonSeattle = 30;
geoplot(latSeattle,lonSeattle);
geobasemap bluegreen;

