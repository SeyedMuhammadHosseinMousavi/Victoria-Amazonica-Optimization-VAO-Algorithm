N=[30 40 50];

nProblem=numel(N);
for k=1:nProblem
    model=CreateRandomModel(N(k));
    ModelName=['phlap_' num2str(model.N)];
    save(ModelName,'model');
end