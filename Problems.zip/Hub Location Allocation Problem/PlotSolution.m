

function PlotSolution(sol,model)

    N=model.N;
    X=model.X;
    Y=model.Y;

    x=sol.x;
    h=sol.h;
    
    xii=diag(x)';
    
    Hubs=find(xii==1);
    nHubs = numel(Hubs);
    Clients=find(xii==0);
    
    Colors = hsv(nHubs)*0.85;
    for i=1:N
        ColorIndex = find(Hubs==h(i));
        Color = Colors(ColorIndex,:); 
        plot([X(i) X(h(i))],[Y(i) Y(h(i))],'k','LineWidth',1,'Color',Color);

        hold on;
    end
    plot(X(Hubs),Y(Hubs),'ko',...
        'MarkerFaceColor','#77AC30',...
        'MarkerSize',17);
    plot(X(Clients),Y(Clients),'b^',...
        'MarkerFaceColor','k',...
        'MarkerSize',12);
    ax = gca; 
ax.FontSize = 12; 
ax.FontWeight='bold';
            hold on;

hold off;

axis equal;
end
