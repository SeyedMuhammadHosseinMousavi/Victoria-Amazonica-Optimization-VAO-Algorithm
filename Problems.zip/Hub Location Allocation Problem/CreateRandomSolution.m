

function xhat=CreateRandomSolution(model)

    N=model.N;
    
    xhat=rand(N,N);

end