
clear;
clc;
warning('off');
img=imread('b.jpg');
img=im2double(img);
% Separating color channels
R=img(:,:,1);
G=img(:,:,2);
B=img(:,:,3);
% Reshaping each channel into a vector and combine all three channels
X=[R(:) G(:) B(:)];

%% Starting FA Clustering
k = 12; % Number of Colors (cluster centers)

%---------------------------------------------------
CostFunction=@(m) ClusterCost(m, X);     % Cost Function
VarSize=[k size(X,2)];           % Decision Variables Matrix Size
nVar=prod(VarSize);              % Number of Decision Variables
VarMin= repmat(min(X),k,1);      % Lower Bound of Variables
VarMax= repmat(max(X),k,1);      % Upper Bound of Variables

%% ICA Parameters

MaxIt = 50;         % Maximum Number of Iterations
nPop = 10;            % Population Size
nEmp = 10;            % Number of Empires/Imperialists

alpha = 1;            % Selection Pressure
beta = 1.5;           % Assimilation Coefficient
pRevolution = 0.05;   % Revolution Probability
mu = 0.1;             % Revolution Rate
zeta = 0.2;           % Colonies Mean Cost Coefficient


%% Globalization of Parameters and Settings

global ProblemSettings;
ProblemSettings.CostFunction = CostFunction;
ProblemSettings.nVar = nVar;
ProblemSettings.VarSize = VarSize;
ProblemSettings.VarMin = VarMin;
ProblemSettings.VarMax = VarMax;

global ICASettings;
ICASettings.MaxIt = MaxIt;
ICASettings.nPop = nPop;
ICASettings.nEmp = nEmp;
ICASettings.alpha = alpha;
ICASettings.beta = beta;
ICASettings.pRevolution = pRevolution;
ICASettings.mu = mu;
ICASettings.zeta = zeta;


%% Initialization

% Initialize Empires
emp = CreateInitialEmpires();

% Array to Hold Best Cost Values
BestCost = zeros(MaxIt, 1);


%% ICA Main Loop

for it = 1:MaxIt

% Assimilation
emp = AssimilateColonies(emp);

% Revolution
% emp = DoRevolution(emp);

% Intra-Empire Competition
emp = IntraEmpireCompetition(emp);

% Update Total Cost of Empires
emp = UpdateTotalCost(emp);

% Inter-Empire Competition
emp = InterEmpireCompetition(emp);

% Update Best Solution Ever Found
imp = [emp.Imp];
[~, BestImpIndex] = min([imp.Cost]);
BestSol = imp(BestImpIndex);

% Update Best Cost
BestCost(it) = BestSol.Cost;
BestRes(it)=BestSol.Cost;   

% Show Iteration Information
disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);

FACenters=Res(X, BestSol);
end
FAlbl=BestSol.Out.ind;


% Plot 
figure('Renderer', 'painters', 'Position', [50 50 250 250])
plot(BestCost,'k','LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
ax = gca; 
ax.FontSize = 12; 
ax.FontWeight='bold';
grid on;

%% Converting cluster centers and its indexes into image 
Z=FACenters(FAlbl',:);
R2=reshape(Z(:,1),size(R));
G2=reshape(Z(:,2),size(G));
B2=reshape(Z(:,3),size(B));
% Attaching color channels 
quantized=zeros(size(img));
quantized(:,:,1)=R2;
quantized(:,:,2)=G2;
quantized(:,:,3)=B2;


% Plot Results 
figure;
% subplot(1,2,1);
% imshow(img);title('Original');
% subplot(1,2,2);
imshow(quantized);title('Quantized Image');


figure('Renderer', 'painters', 'Position', [50 50 250 250])
[counts2, grayLevels2]=imhist(quantized,64);
bar(grayLevels2, counts2,'g','BarWidth', 1);
set(gca,'Color','c',FontSize = 15);



