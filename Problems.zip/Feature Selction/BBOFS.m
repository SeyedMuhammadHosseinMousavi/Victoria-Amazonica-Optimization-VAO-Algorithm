

clc;
clear;
close all;
warning('off');

%% Problem Definition
data=LoadData();
nf=2;   % Desired Number of Selected Features
CostFunction=@(u) FeatureSelectionCost(u,nf,data);        % Cost Function
nVar=data.nx;
VarSize = [1 nVar];   % Decision Variables Matrix Size
VarMin = -10;         % Decision Variables Lower Bound
VarMax = 10;         % Decision Variables Upper Bound

%% BBO Parameters

MaxIt = 50;          % Maximum Number of Iterations
nPop = 3;            % Number of Habitats (Population Size)
KeepRate = 0.2;                   % Keep Rate
nKeep = round(KeepRate*nPop);     % Number of Kept Habitats
nNew = nPop-nKeep;                % Number of New Habitats
% Migration Rates
mu = linspace(1, 0, nPop);          % Emmigration Rates
lambda = 1-mu;                      % Immigration Rates
alpha = 0.9;
pMutation = 0.1;
sigma = 0.02*(VarMax-VarMin);

%% Initialization
% Empty Habitat
habitat.Position = [];
habitat.Cost = [];
habitat.out = [];

% Create Habitats Array
pop = repmat(habitat, nPop, 1);
% Initialize Habitats
for i = 1:nPop
pop(i).Position = unifrnd(VarMin, VarMax, VarSize);
[pop(i).Cost, pop(i).out] = CostFunction(pop(i).Position);
end
% Sort Population
[~, SortOrder] = sort([pop.Cost]);
pop = pop(SortOrder);
% Best Solution Ever Found
BestSol = pop(1);
% Array to Hold Best Costs
BestCost = zeros(MaxIt, 1);

%% BBO Main Loop
for it = 1:MaxIt
newpop = pop;
for i = 1:nPop
for k = 1:nVar
% Migration
if rand <= lambda(i)
% Emmigration Probabilities
EP = mu;
EP(i) = 0;
EP = EP/sum(EP);
% Select Source Habitat
j = RouletteWheelSelection(EP);
% Migration
newpop(i).Position(k) = pop(i).Position(k) ...
+alpha*(pop(j).Position(k)-pop(i).Position(k));
end
% Mutation
if rand <= pMutation
newpop(i).Position(k) = newpop(i).Position(k)+sigma*randn;
end
end
% Apply Lower and Upper Bound Limits
newpop(i).Position = max(newpop(i).Position, VarMin);
newpop(i).Position = min(newpop(i).Position, VarMax);
% Evaluation
[newpop(i).Cost newpop(i).out] = CostFunction(newpop(i).Position);
end
% Sort New Population
[~, SortOrder] = sort([newpop.Cost]);
newpop = newpop(SortOrder);
% Select Next Iteration Population
pop = [pop(1:nKeep)
newpop(1:nNew)];
% Sort Population
[~, SortOrder] = sort([pop.Cost]);
pop = pop(SortOrder);
% Update Best Solution Ever Found
BestSol = pop(1);
% Store Best Cost Ever Found
BestCost(it) = BestSol.Cost;
% Show Iteration Information
disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
end

%% Itr
figure;
plot(BestCost, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;


%% BBO Feature Matrix
% Extracting Data
RealData=data.x';
% Extracting Labels
RealLbl=data.t';
FinalFeaturesInd=BestSol.out.S;
% Sort Features
FFI=sort(FinalFeaturesInd);
% Select Final Features
BBO_Features=RealData(:,FFI);
% Adding Labels
BBO_Features_Lbl=BBO_Features;
BBO_Features_Lbl(:,end+1)=RealLbl;
BBOFinal=BBO_Features_Lbl;
