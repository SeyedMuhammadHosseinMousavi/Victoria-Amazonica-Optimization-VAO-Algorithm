
clc;
clear;
close all;
warning('off');

%% Problem Definition
data=LoadData();
nf=7;   % Desired Number of Selected Features
CostFunction=@(u) FeatureSelectionCost(u,nf,data);        % Cost Function
nVar=data.nx;
VarSize = [1 nVar];   % Decision Variables Matrix Size
VarMin = -10;         % Decision Variables Lower Bound
VarMax = 10;         % Decision Variables Upper Bound



%% ICA Parameters

MaxIt = 50;         % Maximum Number of Iterations
nPop = 3;            % Population Size
nEmp = 2;            % Number of Empires/Imperialists

alpha = 1;            % Selection Pressure
beta = 1.5;           % Assimilation Coefficient
pRevolution = 0.05;   % Revolution Probability
mu = 0.1;             % Revolution Rate
zeta = 0.2;           % Colonies Mean Cost Coefficient


%% Globalization of Parameters and Settings

global ProblemSettings;
ProblemSettings.CostFunction = CostFunction;
ProblemSettings.nVar = nVar;
ProblemSettings.VarSize = VarSize;
ProblemSettings.VarMin = VarMin;
ProblemSettings.VarMax = VarMax;

global ICASettings;
ICASettings.MaxIt = MaxIt;
ICASettings.nPop = nPop;
ICASettings.nEmp = nEmp;
ICASettings.alpha = alpha;
ICASettings.beta = beta;
ICASettings.pRevolution = pRevolution;
ICASettings.mu = mu;
ICASettings.zeta = zeta;


%% Initialization

% Initialize Empires
emp = CreateInitialEmpires();

% Array to Hold Best Cost Values
BestCost = zeros(MaxIt, 1);


%% ICA Main Loop

for it = 1:MaxIt

% Assimilation
emp = AssimilateColonies(emp);

% Revolution
emp = DoRevolution(emp);

% Intra-Empire Competition
emp = IntraEmpireCompetition(emp);

% Update Total Cost of Empires
emp = UpdateTotalCost(emp);

% Inter-Empire Competition
emp = InterEmpireCompetition(emp);

% Update Best Solution Ever Found
imp = [emp.Imp];
[~, BestImpIndex] = min([imp.Cost]);
BestSol = imp(BestImpIndex);

% Update Best Cost
BestCost(it) = BestSol.Cost;

% Show Iteration Information
disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);

end

%% Itr
figure;
plot(BestCost,'k','LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
ax = gca; 
ax.FontSize = 12; 
ax.FontWeight='bold';
grid on;


%% BBO Feature Matrix
% Extracting Data
RealData=data.x';
% Extracting Labels
RealLbl=data.t';
FinalFeaturesInd=BestSol.Sol.S;
% Sort Features
FFI=sort(FinalFeaturesInd);
% Select Final Features
BBO_Features=RealData(:,FFI);
% Adding Labels
BBO_Features_Lbl=BBO_Features;
BBO_Features_Lbl(:,end+1)=RealLbl;
BBOFinal=BBO_Features_Lbl;
