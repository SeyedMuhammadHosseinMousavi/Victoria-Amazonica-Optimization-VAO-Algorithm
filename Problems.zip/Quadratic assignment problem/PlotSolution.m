
function PlotSolution(s, model)

[~, p] = sort(s);

n=model.n;
x=model.x;
y=model.y;

plot(x(p(1:n)),y(p(1:n)),'kp',...
'MarkerSize',14,...
'MarkerFaceColor','r');                 % Assigned Locations

hold on;

plot(x(p(n+1:end)),y(p(n+1:end)),'bs','MarkerSize',14,'MarkerFaceColor','g');     % Not-Assigned Locations
ax = gca; 
ax.FontSize = 12; 
ax.FontWeight='bold';
for i=1:n
text(x(p(i))+1,y(p(i))-2,num2str(i),'FontSize',15);
end

hold off;
grid on;
axis equal;

end