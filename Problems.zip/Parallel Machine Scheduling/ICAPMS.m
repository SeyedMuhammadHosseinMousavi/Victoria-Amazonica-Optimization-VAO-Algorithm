clc;
clear;
close all;
global NFE;
NFE=0;

%% Problem Definition
model=CreateModel2();        % Create Model of the Problem
CostFunction=@(x) MyCost(x,model);       % Cost Function
nVar=model.nVar;        % Number of Decision Variables
VarSize=[1 nVar];       % Size of Decision Variables Matrix
VarMin = 0;          % Lower Bound of Decision Variables
VarMax = 1;          % Upper Bound of Decision Variables


%% ICA Parameters

MaxIt = 100;         % Maximum Number of Iterations
nPop = 20;            % Population Size
nEmp = 10;            % Number of Empires/Imperialists

alpha = 2;            % Selection Pressure
beta = 1.5;           % Assimilation Coefficient
pRevolution = 0.05;   % Revolution Probability
mu = 0.1;             % Revolution Rate
zeta = 0.2;           % Colonies Mean Cost Coefficient


%% Globalization of Parameters and Settings

global ProblemSettings;
ProblemSettings.CostFunction = CostFunction;
ProblemSettings.nVar = nVar;
ProblemSettings.VarSize = VarSize;
ProblemSettings.VarMin = VarMin;
ProblemSettings.VarMax = VarMax;

global ICASettings;
ICASettings.MaxIt = MaxIt;
ICASettings.nPop = nPop;
ICASettings.nEmp = nEmp;
ICASettings.alpha = alpha;
ICASettings.beta = beta;
ICASettings.pRevolution = pRevolution;
ICASettings.mu = mu;
ICASettings.zeta = zeta;


%% Initialization

% Initialize Empires
emp = CreateInitialEmpires();

% Array to Hold Best Cost Values
BestCost = zeros(MaxIt, 1);


%% ICA Main Loop

for it = 1:MaxIt

% Assimilation
emp = AssimilateColonies(emp);

% Revolution
emp = DoRevolution(emp);

% Intra-Empire Competition
emp = IntraEmpireCompetition(emp);

% Update Total Cost of Empires
emp = UpdateTotalCost(emp);

% Inter-Empire Competition
emp = InterEmpireCompetition(emp);

% Update Best Solution Ever Found
imp = [emp.Imp];
[~, BestImpIndex] = min([imp.Cost]);
BestSol = imp(BestImpIndex);

% Update Best Cost
BestCost(it) = BestSol.Cost;
% Store NFE
nfe(it)=NFE;
% Show Iteration Information
disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
% Plot Res
% figure(1);
% PlotSolution(BestSol.Sol,model);
end

%% Show Results
figure(1);
PlotSolution(BestSol.Sol,model);

figure;
plot(BestCost,'k','LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
ax = gca; 
ax.FontSize = 12; 
ax.FontWeight='bold';
grid on;
