% aa=0;

b=bar3(aa,0.6);
b(2).FaceColor = [.9 .7 .8];
b(1).FaceColor = 'white';
b(3).FaceColor = 'green';
b(4).FaceColor = 'red';
b(5).FaceColor = 'blue';
b(6).FaceColor = 'cyan';

ax = gca; 
ax.FontSize = 15; 
set(gca,'Color','k')