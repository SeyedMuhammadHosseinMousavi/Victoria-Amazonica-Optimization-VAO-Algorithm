
I=10; % Tasks
J=3; % Machines
p=randi([10 50],I,J); % Process time 

% S is setup time 
S1=randi([3 9],I,I);
S2=randi([3 9],I,I);
S3=randi([3 9],I,I);

%Maximum machine completion time is Cmax

% NFE is the number of investigated solutions. Lower the better 