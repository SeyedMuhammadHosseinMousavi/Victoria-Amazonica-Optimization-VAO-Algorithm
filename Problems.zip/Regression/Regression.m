
clear;
Data=load('daily.mat');
Inputs=Data.ff(:,1:end-1);
Targets=rescale(Data.ff(:,end));
%% Learning 
n = 9; % Neurons
%----------------------------------------
% 'trainlm'	    Levenberg-Marquardt
% 'trainbr' 	Bayesian Regularization (good)
% 'trainrp'  	Resilient Backpropagation
% 'traincgf'	Fletcher-Powell Conjugate Gradient
% 'trainoss'	One Step Secant (good)
% 'traingd' 	Gradient Descent
% Creating the NN ----------------------------
net = feedforwardnet(n,'trainoss');
%---------------------------------------------
% configure the neural network for this dataset
[net tr]= train(net,Inputs', Targets');
perf = perform(net,Inputs, Targets); % mse
% Current NN Weights and Bias
Weights_Bias = getwb(net);
% MSE Error for Current NN
Outputs=net(Inputs');
Outputs=Outputs';
% Final MSE Error and Correlation Coefficients (CC)
Err_MSE=mse(Targets,Outputs);
CC1= corrcoef(Targets,Outputs);
CC1= CC1(1,2);
%-----------------------------------------------------
%% Nature Inspired Regression
% Create Handle for Error
h = @(x) NMSE(x, net, Inputs', Targets');
sizenn=size(Inputs);sizenn=sizenn(1,1);
%-----------------------------------------

%PSO
% [x, cost] = PSO(h, sizenn*n+n+n+1);
%FA
% [x, cost] = FA(h, sizenn*n+n+n+1);
%DE
% [x, cost] = DE(h, sizenn*n+n+n+1);
%HS
% [x, cost] = HS(h, sizenn*n+n+n+1);
%ICA
% [x, cost] = ICA(h, sizenn*n+n+n+1);
%VAO
[x, cost] = VAO(h, sizenn*n+n+n+1);


%-----------------------------------------
net = setwb(net, x');
% Optimized NN Weights and Bias
getwb(net);
% Error for Optimized NN
Outputs2=net(Inputs');
Outputs2=Outputs2';
% Final MSE Error and Correlation Coefficients (CC)
Err_MSE2=mse(Targets,Outputs2);
CC2= corrcoef(Targets,Outputs2);
CC2= CC2(1,2);

%% Plot Regression
% figure('units','normalized','outerposition',[0 0 1 1])
% Normal
% subplot(1,2,1)
% [population2,gof] = fit(Targets,Outputs,'poly2');
% plot(Targets,Outputs,'o',...
% 'LineWidth',1,...
% 'MarkerSize',8,...
% 'MarkerEdgeColor','r',...
% 'MarkerFaceColor',[0.3,0.9,0.1]);
% title(['Normal R =  ' num2str(1-gof.rmse)],['Normal MSE =  ' num2str(Err_MSE)]);
% hold on
% plot(population2,'b-','predobs');
% xlabel('Targets');ylabel('Outputs');   grid on;
% ax = gca; 
% ax.FontSize = 12; ax.LineWidth=2;
% legend({'Normal Regression'},'FontSize',12,'TextColor','blue');hold off
% PSO
% subplot(1,2,2)
figure;
[population3,gof3] = fit(Targets,Outputs2,'poly2');
plot(Targets,Outputs2,'o',...
'LineWidth',1,...
'MarkerSize',8,...
'MarkerEdgeColor','g',...
'MarkerFaceColor',[0.9,0.3,0.1]);
title(['MSE =  ' num2str(Err_MSE2)]); 
hold on
plot(population3,'b-','predobs');
xlabel('Targets','FontSize',12,'FontWeight','bold');ylabel('Outputs','FontSize',12,'FontWeight','bold');
grid on;
ax = gca; 
ax.FontSize = 12; 
ax.LineWidth=2;
% legend({'PSO Regression'},'FontSize',12,'TextColor','blue');hold off

% Correlation Coefficients
% fprintf('Normal MSE Is =  %0.4f.\n',Err_MSE);
% fprintf('Normal RMSE Is =  %0.4f.\n',sqrt(Err_MSE));
fprintf('Optimized MSE Is =  %0.4f.\n',Err_MSE2);
fprintf('Optimized RMSE Is =  %0.4f.\n',sqrt(Err_MSE2));
% fprintf('Normal Correlation Coefficients Is =  %0.4f.\n',CC1);
fprintf('Optimized Correlation Coefficients Is =  %0.4f.\n',CC2);


