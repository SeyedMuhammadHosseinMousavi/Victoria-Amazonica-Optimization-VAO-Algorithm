

%% Starting ICA Clustering
clear;
warning('off');
% Loading
X = iris_dataset';
%
k = 3; % Number of Clusters
%
CostFunction=@(m) ClusterCost(m, X);     % Cost Function
VarSize=[k size(X,2)];           % Decision Variables Matrix Size
nVar=prod(VarSize);              % Number of Decision Variables
VarMin= repmat(min(X),k,1);      % Lower Bound of Variables
VarMax= repmat(max(X),k,1);      % Upper Bound of Variables
%% ICA Parameters

MaxIt = 300;         % Maximum Number of Iterations
nPop = 30;            % Population Size
nEmp = 25;            % Number of Empires/Imperialists

alpha = 1;            % Selection Pressure
beta = 1.5;           % Assimilation Coefficient
pRevolution = 0.05;   % Revolution Probability
mu = 0.1;             % Revolution Rate
zeta = 0.2;           % Colonies Mean Cost Coefficient


%% Globalization of Parameters and Settings

global ProblemSettings;
ProblemSettings.CostFunction = CostFunction;
ProblemSettings.nVar = nVar;
ProblemSettings.VarSize = VarSize;
ProblemSettings.VarMin = VarMin;
ProblemSettings.VarMax = VarMax;

global ICASettings;
ICASettings.MaxIt = MaxIt;
ICASettings.nPop = nPop;
ICASettings.nEmp = nEmp;
ICASettings.alpha = alpha;
ICASettings.beta = beta;
ICASettings.pRevolution = pRevolution;
ICASettings.mu = mu;
ICASettings.zeta = zeta;


%% Initialization

% Initialize Empires
emp = CreateInitialEmpires();

% Array to Hold Best Cost Values
BestCost = zeros(MaxIt, 1);


%% ICA Main Loop

for it = 1:MaxIt

% Assimilation
emp = AssimilateColonies(emp);

% Revolution
% emp = DoRevolution(emp);

% Intra-Empire Competition
emp = IntraEmpireCompetition(emp);

% Update Total Cost of Empires
emp = UpdateTotalCost(emp);

% Inter-Empire Competition
emp = InterEmpireCompetition(emp);

% Update Best Solution Ever Found
imp = [emp.Imp];
[~, BestImpIndex] = min([imp.Cost]);
BestSol = imp(BestImpIndex);

% Update Best Cost
BestCost(it) = BestSol.Cost;

% Show Iteration Information
disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
% DECenters=PlotRes(X, BestSol);
% pause(0.01);
end
%

figure(1);
PlotRes(X, BestSol);
%% Res
figure;
plot(BestCost,'k','LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
ax = gca; 
ax.FontSize = 12; 
ax.FontWeight='bold';
grid on;
